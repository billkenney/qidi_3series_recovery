#!/bin/bash

export_gpio() {
    local gpio_path="/sys/class/gpio/gpio$1"
    if [ ! -d "$gpio_path" ]; then
        echo "$1" > /sys/class/gpio/export
    fi
    echo "$2" > "$gpio_path/direction"
}

# 导出和设置 GPIO 53
export_gpio 53 out
# echo 1 > /sys/class/gpio/gpio53/value

# 导出和设置 GPIO 42
export_gpio 42 in

while :
do
    read -r level < /sys/class/gpio/gpio42/value

    if [ "$level" == 1 ]; then
        # echo 1 > /sys/class/gpio/gpio53/value
        sync
        shutdown -h now
        break
    fi
    sync
    sleep 1
done
